class recordtimes:
    min_athletes = 4
    max_athletes = 8

    mens_record_times = {"World Record Time": 9.58, "European Record Time": 9.86, "British Record Time": 9.87}
    womens_record_times = {"World Record Time": 10.49, "European Record Time": 10.73, "British Record Time": 10.99}